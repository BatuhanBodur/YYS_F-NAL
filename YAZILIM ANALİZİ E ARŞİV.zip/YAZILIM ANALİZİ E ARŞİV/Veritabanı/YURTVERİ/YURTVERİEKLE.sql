-- AdvisorCalendars tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[AdvisorCalendars] ON;
INSERT INTO [dbo].[AdvisorCalendars] ([Id], [UserId], [AdvisortDate], [Period], [IsActive]) VALUES
(1, 3, '2024-12-24T13:45:00.000', 1, 1),
(2, 3, '2024-12-25T14:00:00.000', 2, 1),
(3, 3, '2024-12-26T15:00:00.000', 3, 1);
SET IDENTITY_INSERT [dbo].[AdvisorCalendars] OFF;

-- AllRoomAndDormitoryChanges tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[AllRoomAndDormitoryChanges] ON;
INSERT INTO [dbo].[AllRoomAndDormitoryChanges] ([Id], [RequestingStudentId], [RequestedStudentId], [Status]) VALUES
(1, 4, 4, 1),
(2, 4, 5, 2),
(3, 5, 4, 3);
SET IDENTITY_INSERT [dbo].[AllRoomAndDormitoryChanges] OFF;

-- Announcements tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[Announcements] ON;
INSERT INTO [dbo].[Announcements] ([Id], [AnnouncementsTitle], [AnnouncementsDescription], [AnnouncementsImage], [AnnouncementsDate], [IsActive]) VALUES
(1, N'Yeni Dönem Başlıyor', N'Yeni dönem 1 Ocak 2025 tarihinde başlayacaktır.', NULL, '2024-12-01T00:00:00.000', 1),
(2, N'Yemekhane Açılışı', N'Yemekhane 2 Ocak 2025 tarihinde açılacaktır.', NULL, '2024-12-02T00:00:00.000', 1),
(3, N'Spor Salonu Bakımı', N'Spor salonu 3 Ocak 2025 tarihinde bakıma alınacaktır.', NULL, '2024-12-03T00:00:00.000', 1);
SET IDENTITY_INSERT [dbo].[Announcements] OFF;

-- CommunicationTables tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[CommunicationTables] ON;
INSERT INTO [dbo].[CommunicationTables] ([Id], [UserId], [CreatedDate], [Description]) VALUES
(1, 4, '2024-12-01T10:00:00.000', N'Öğrenci 1 ile iletişim kuruldu.'),
(2, 5, '2024-12-02T11:00:00.000', N'Yönetici 1 ile iletişim kuruldu.'),
(3, 3, '2024-12-03T12:00:00.000', N'Danışman 1 ile iletişim kuruldu.');
SET IDENTITY_INSERT [dbo].[CommunicationTables] OFF;

-- Courses tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[Courses] ON;
INSERT INTO [dbo].[Courses] ([Id], [CourseName], [CourseDate], [CourseQuota], [CourseTime], [CourseDays], [MentorUserId], [IsActive]) VALUES
(1, N'Matematik 101', '2025-01-10T09:00:00.000', 30, 60, N'Pazartesi', 3, 1),
(2, N'Fizik 101', '2025-01-11T10:00:00.000', 25, 60, N'Salı', 3, 1),
(3, N'Kimya 101', '2025-01-12T11:00:00.000', 20, 60, N'Çarşamba', 3, 1);
SET IDENTITY_INSERT [dbo].[Courses] OFF;

-- Dormitories tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[Dormitories] ON;
INSERT INTO [dbo].[Dormitories] ([Id], [DormitoryName], [DormitoryAddress], [DormitoryQuota], [RoomNumber]) VALUES
(1, N'A Blok', N'123 Ana Cadde', 100, 50),
(2, N'B Blok', N'456 Yan Cadde', 80, 40),
(3, N'C Blok', N'789 Yan Sokak', 60, 30);
SET IDENTITY_INSERT [dbo].[Dormitories] OFF;

-- DormitoryExpenses tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[DormitoryExpenses] ON;
INSERT INTO [dbo].[DormitoryExpenses] ([Id], [ExpenseType], [SpendingAmount], [SpendingTime]) VALUES
(1, 1, 5000.00, '2024-12-01T00:00:00.000'),
(2, 2, 3000.00, '2024-12-02T00:00:00.000'),
(3, 3, 2000.00, '2024-12-03T00:00:00.000');
SET IDENTITY_INSERT [dbo].[DormitoryExpenses] OFF;

-- GuestStudents tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[GuestStudents] ON;
INSERT INTO [dbo].[GuestStudents] ([Id], [Name], [Surname], [IdentityNo], [PhoneNumber], [StartDate], [EndDate], [TotalPrice]) VALUES
(1, N'Misafir 1', N'Soyad 1', N'12345678901', N'5551112233', '2024-12-01T00:00:00.000', '2024-12-10T00:00:00.000', 1000.00),
(2, N'Misafir 2', N'Soyad 2', N'12345678902', N'5552223344', '2024-12-02T00:00:00.000', '2024-12-11T00:00:00.000', 1200.00),
(3, N'Misafir 3', N'Soyad 3', N'12345678903', N'5553334455', '2024-12-03T00:00:00.000', '2024-12-12T00:00:00.000', 1500.00);
SET IDENTITY_INSERT [dbo].[GuestStudents] OFF;

-- MealTables tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[MealTables] ON;
INSERT INTO [dbo].[MealTables] ([Id], [StarterMeal], [MainMeal], [Dessert], [Drink], [MealDate]) VALUES
(1, N'Çorba', N'Tavuk', N'Pasta', N'Su', '2024-12-01T12:00:00.000'),
(2, N'Salata', N'Köfte', N'Dondurma', N'Ayran', '2024-12-02T12:00:00.000'),
(3, N'Ezogelin', N'Balık', N'Kek', N'Meyve Suyu', '2024-12-03T12:00:00.000');
SET IDENTITY_INSERT [dbo].[MealTables] OFF;

-- Payments tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[Payments] ON;
INSERT INTO [dbo].[Payments] ([Id], [UserId], [Period], [IsPayment], [Price]) VALUES
(1, 4, '2024-12-01T00:00:00.000', 1, 500),
(2, 5, '2024-12-02T00:00:00.000', 1, 600),
(3, 3, '2024-12-03T00:00:00.000', 1, 700);
SET IDENTITY_INSERT [dbo].[Payments] OFF;

-- Permissions tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[Permissions] ON;
INSERT INTO [dbo].[Permissions] ([PermissionId], [StudentId], [PermissionUsedAddress], [PermitStartDate], [PermitExpirationDate], [PermissionStatement], [ApprovedId], [IsActive]) VALUES
(1, 4, N'Ankara', '2024-12-01T00:00:00.000', '2024-12-10T00:00:00.000', N'İzin talebi onaylandı.', 3, 1),
(2, 5, N'İstanbul', '2024-12-02T00:00:00.000', '2024-12-11T00:00:00.000', N'İzin talebi onaylandı.', 3, 1),
(3, 3, N'İzmir', '2024-12-03T00:00:00.000', '2024-12-12T00:00:00.000', N'İzin talebi onaylandı.', 3, 1);
SET IDENTITY_INSERT [dbo].[Permissions] OFF;

-- RoomInformations tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[RoomInformations] ON;
INSERT INTO [dbo].[RoomInformations] ([Id], [RoomNo], [FloorNo], [BedNumber], [TotalPerson], [DormitoriesId]) VALUES
(1, 101, 1, 2, 2, 1),
(2, 102, 1, 2, 2, 1),
(3, 201, 2, 2, 2, 2);
SET IDENTITY_INSERT [dbo].[RoomInformations] OFF;

-- SportReservations tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[SportReservations] ON;
INSERT INTO [dbo].[SportReservations] ([Id], [SportType], [SportDate], [Period], [IsActive]) VALUES
(1, 1, '2024-12-01T10:00:00.000', 1, 1),
(2, 2, '2024-12-02T11:00:00.000', 2, 1),
(3, 3, '2024-12-03T12:00:00.000', 3, 1);
SET IDENTITY_INSERT [dbo].[SportReservations] OFF;

-- StudentCourseRecords tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[StudentCourseRecords] ON;
INSERT INTO [dbo].[StudentCourseRecords] ([Id], [UserId], [CourseId]) VALUES
(1, 4, 1),
(2, 5, 2),
(3, 3, 3);
SET IDENTITY_INSERT [dbo].[StudentCourseRecords] OFF;

-- StudentDetails tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[StudentDetails] ON;
INSERT INTO [dbo].[StudentDetails] ([DetailId], [StudentId], [DormitoryBlock], [DormitoryFloor], [DormitoryRoomNumber], [DormitoryBedNumber]) VALUES
(1, 4, N'A', N'1', N'101', N'1'),
(2, 5, N'B', N'2', N'201', N'2'),
(3, 3, N'C', N'3', N'301', N'3');
SET IDENTITY_INSERT [dbo].[StudentDetails] OFF;

-- StudentPermissions tablosuna veri ekleme
SET IDENTITY_INSERT [dbo].[StudentPermissions] ON;
INSERT INTO [dbo].[StudentPermissions] ([Id], [Address], [ExitDate], [ReturnDate], [Description], [IsActive]) VALUES
(1, N'Ankara', '2024-12-01T00:00:00.000', '2024-12-10T00:00:00.000', N'İzin talebi onaylandı.', 1),
(2, N'İstanbul', '2024-12-02T00:00:00.000', '2024-12-11T00:00:00.000', N'İzin talebi onaylandı.', 1),
(3, N'İzmir', '2024-12-03T00:00:00.000', '2024-12-12T00:00:00.000', N'İzin talebi onaylandı.', 1);
SET IDENTITY_INSERT [dbo].[StudentPermissions] OFF;

-- Users tablosuna veri ekleme (Zaten eklenmişti, burada tekrar eklenmiyor)