Belgeler: İçerisinde Raporlar ve sunum slaytları bulunmaktadır.

Görseller: İçerisinde kullanılan iconlar ve giriş sayfası resimleri bulunmaktadır.

Kaynak Kod: İçerisinde Html, Css, Javascript ve C# olarak projede kullandığımız kaynak kodları bulunmaktadır.

Testler: İçerisinde birim ve entegrasyon testleri bulunmaktadır.

Veritabanı: İçerisinde veritabanı oluşturma ve veri ekleme dosyaları vardır. Önce Oluşturma sonrasında Ekleme dosyası çalıştırılmalıdır. 

Tasarım: Sistemi geliştirirken kullandığımız sınıf ve use case diyagramları bulunmaktadır.