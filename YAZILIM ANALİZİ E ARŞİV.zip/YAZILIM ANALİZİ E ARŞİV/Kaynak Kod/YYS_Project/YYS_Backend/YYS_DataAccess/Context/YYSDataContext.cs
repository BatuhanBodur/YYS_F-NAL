﻿using Microsoft.EntityFrameworkCore;
using YYS_Model.Entities;

namespace YYS_DataAccess.Context
{
    public class YYSDataContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                //.UseSqlServer("Data Source=.\\SQLEXPRESS;Initial Catalog=yurtyonetimsistemi;Integrated Security=True;TrustServerCertificate=True;");
                .UseSqlServer("Server=localhost;Database=YURT;Integrated Security=True;TrustServerCertificate=True;Trusted_Connection=True;");
            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<AdvisorCalendar> AdvisorCalendars { get; set; }
        public DbSet<AllRoomAndDormitoryChange> AllRoomAndDormitoryChanges { get; set; }
        public DbSet<Announcement> Announcements { get; set; }
        public DbSet<CommunicationTable> CommunicationTables { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Dormitorie> Dormitories { get; set; }
        public DbSet<DormitoryExpense> DormitoryExpenses { get; set; }
        public DbSet<GuestStudent> GuestStudents { get; set; }
        public DbSet<MealTable> MealTables { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Permission> Permissions { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<RoomInformation> RoomInformations { get; set; }
        public DbSet<SportReservation> SportReservations { get; set; }
        public DbSet<StudentCourseRecord> StudentCourseRecords { get; set; }
        public DbSet<StudentDetail> StudentDetails { get; set; }
        public DbSet<StudentPermission> StudentPermissions { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
