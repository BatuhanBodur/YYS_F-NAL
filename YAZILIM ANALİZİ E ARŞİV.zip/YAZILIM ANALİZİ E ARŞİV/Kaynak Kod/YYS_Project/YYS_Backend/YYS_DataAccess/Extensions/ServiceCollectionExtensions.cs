﻿using Microsoft.Extensions.DependencyInjection;
using YYS_DataAccess.Interfaces;
using YYS_DataAccess.Repositories;

namespace YYS_DataAccess.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddBusinessServices(this IServiceCollection services)
        {
            services.AddScoped<IAdvisorCalendarRepository, AdvisorCalendarRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IAnnouncementRepository, AnnouncementRepository>();
            services.AddScoped<IMealTableRepository, MealTableRepository>();
            services.AddScoped<IAllRoomAndDormitoryChangeRepository, AllRoomAndDormitoryChangeRepository>();
            services.AddScoped<ICommunicationTableRepository, CommunicationTableRepository>();
            services.AddScoped<ICourseRepository, CourseRepository>();
            services.AddScoped<IDormitorieRepository, DormitorieRepository>();
            services.AddScoped<IGuestStudentRepository, GuestStudentRepository>();
            services.AddScoped<IPermissionRepository, PermissionRepository>();
            services.AddScoped<IRoomInformationRepository, RoomInformationRepository>();
            services.AddScoped<ISportReservationRepository, SportReservationRepository>();
            services.AddScoped<IStudentCourseRecordRepository, StudentCourseRecordRepository>();
            services.AddScoped<IStudentDetailRepository, StudentDetailRepository>();
            services.AddScoped<IStudentPermissionRepository, StudentPermissionRepository>();
            
        }
    }
}
