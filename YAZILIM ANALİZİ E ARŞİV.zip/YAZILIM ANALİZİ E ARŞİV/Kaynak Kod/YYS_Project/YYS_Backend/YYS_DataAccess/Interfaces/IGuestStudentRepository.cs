using Utils;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Interfaces
{
    public interface IGuestStudentRepository : IBaseRepository<GuestStudent>
    {
        Task<List<GuestStudent>> GetAllGuestStudentsAsync();
    }
}
