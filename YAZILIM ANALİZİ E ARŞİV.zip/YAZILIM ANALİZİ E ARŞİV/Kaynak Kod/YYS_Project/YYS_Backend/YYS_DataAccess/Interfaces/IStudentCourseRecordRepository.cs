using Utils;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Interfaces
{
    public interface IStudentCourseRecordRepository : IBaseRepository<StudentCourseRecord>
    {
        Task<List<StudentCourseRecord>> GetAllByUserIdAsync(int userId);
        Task<List<StudentCourseRecord>> GetAllByCourseIdAsync(int courseId);
    }
}
