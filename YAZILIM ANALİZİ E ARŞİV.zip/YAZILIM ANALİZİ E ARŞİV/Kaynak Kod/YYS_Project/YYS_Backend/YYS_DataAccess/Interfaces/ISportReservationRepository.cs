using Utils;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Interfaces
{
    public interface ISportReservationRepository : IBaseRepository<SportReservation>
    {
        Task<List<SportReservation>> GetAllSportReservationsAsync();
    }
}
