using Utils;
using YYS_Model.Entities;
using System.Threading.Tasks;

namespace YYS_DataAccess.Interfaces
{
    public interface IStudentDetailRepository : IBaseRepository<StudentDetail>
    {
        Task<StudentDetail> GetByStudentIdAsync(int studentId);
    }
}
