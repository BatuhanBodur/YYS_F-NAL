using Utils;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Interfaces
{
    public interface IAllRoomAndDormitoryChangeRepository : IBaseRepository<AllRoomAndDormitoryChange>
    {
        Task<List<AllRoomAndDormitoryChange>> GetAllRoomAndDormitoryChangesAsync();
        Task<AllRoomAndDormitoryChange> GetByIdAsync(int id);
    }
}
