﻿using Utils;
using YYS_Model.Entities;

namespace YYS_DataAccess.Interfaces
{
    public interface IUserRepository : IBaseRepository<User>
    {
        Task<User> LoginUser(string identityNo, string password);
    }
}
