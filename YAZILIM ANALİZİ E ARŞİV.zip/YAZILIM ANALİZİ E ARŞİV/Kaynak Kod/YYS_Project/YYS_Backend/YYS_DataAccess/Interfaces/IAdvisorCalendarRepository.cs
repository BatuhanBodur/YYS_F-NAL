﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils;
using YYS_Model.Entities;

namespace YYS_DataAccess.Interfaces
{
    public interface IAdvisorCalendarRepository : IBaseRepository<AdvisorCalendar>
    {
        Task<List<AdvisorCalendar>> GetAllAdvisorCalendar();
    }
}
