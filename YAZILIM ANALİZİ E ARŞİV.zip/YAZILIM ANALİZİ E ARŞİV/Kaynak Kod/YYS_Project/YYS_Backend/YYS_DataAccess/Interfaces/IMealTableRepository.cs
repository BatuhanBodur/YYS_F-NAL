using Utils;
using YYS_Model.Entities;

namespace YYS_DataAccess.Interfaces
{
   public interface IMealTableRepository : IBaseRepository<MealTable>
    {
        Task<List<MealTable>> GetAllMeals();
    }
}
