﻿using Utils;
using YYS_Model.Entities;

namespace YYS_DataAccess.Interfaces
{
    public interface IAnnouncementRepository : IBaseRepository<Announcement>
    {
        Task<List<Announcement>> GetAllAnnouncements();
    }
}
