﻿using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_DataAccess.Repositories
{
    public class AnnouncementRepository : BaseRepository<Announcement, YYSDataContext>, IAnnouncementRepository
    {
        public async Task<List<Announcement>> GetAllAnnouncements()
        {
            return await GetAllAsync();
        }
    }
}
