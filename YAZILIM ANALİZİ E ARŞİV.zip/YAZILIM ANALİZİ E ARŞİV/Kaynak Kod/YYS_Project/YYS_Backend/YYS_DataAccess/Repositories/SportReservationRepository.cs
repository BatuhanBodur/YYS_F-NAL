using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class SportReservationRepository : BaseRepository<SportReservation, YYSDataContext>, ISportReservationRepository
    {
        public async Task<List<SportReservation>> GetAllSportReservationsAsync()
        {
            return await GetAllAsync();
        }
    }
}
