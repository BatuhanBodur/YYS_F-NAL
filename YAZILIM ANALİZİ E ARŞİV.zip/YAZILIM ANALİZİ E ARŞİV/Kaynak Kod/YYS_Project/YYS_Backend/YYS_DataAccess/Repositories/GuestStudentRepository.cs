using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class GuestStudentRepository : BaseRepository<GuestStudent, YYSDataContext>, IGuestStudentRepository
    {
        public async Task<List<GuestStudent>> GetAllGuestStudentsAsync()
        {
            return await GetAllAsync();
        }
    }
}
