using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class CourseRepository : BaseRepository<Course, YYSDataContext>, ICourseRepository
    {
        public async Task<List<Course>> GetAllCoursesAsync()
        {
            return await GetAllAsync();
        }
    }
}
