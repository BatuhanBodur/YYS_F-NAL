﻿using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_DataAccess.Repositories
{
    public class AdvisorCalendarRepository : BaseRepository<AdvisorCalendar, YYSDataContext>, IAdvisorCalendarRepository
    {
        public async Task<List<AdvisorCalendar>> GetAllAdvisorCalendar()
        {
            return await GetAllAsync();
        }
    }
}
