using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class StudentCourseRecordRepository : BaseRepository<StudentCourseRecord, YYSDataContext>, IStudentCourseRecordRepository
    {
        public async Task<List<StudentCourseRecord>> GetAllByUserIdAsync(int userId)
        {
            return await GetAllAsync(scr => scr.UserId == userId);
        }

        public async Task<List<StudentCourseRecord>> GetAllByCourseIdAsync(int courseId)
        {
            return await GetAllAsync(scr => scr.CourseId == courseId);
        }
    }
}
