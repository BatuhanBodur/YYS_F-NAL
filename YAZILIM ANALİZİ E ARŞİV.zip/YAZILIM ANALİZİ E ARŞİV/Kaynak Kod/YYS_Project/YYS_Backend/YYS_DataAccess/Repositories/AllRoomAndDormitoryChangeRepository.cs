using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class AllRoomAndDormitoryChangeRepository : BaseRepository<AllRoomAndDormitoryChange, YYSDataContext>, IAllRoomAndDormitoryChangeRepository
    {
        public async Task<List<AllRoomAndDormitoryChange>> GetAllRoomAndDormitoryChangesAsync()
        {
            return await GetAllAsync();
        }

        public async Task<AllRoomAndDormitoryChange> GetByIdAsync(int id)
        {
            return await GetAsync(e => e.Id == id);
        }
    }
}
