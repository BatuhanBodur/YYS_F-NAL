﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_DataAccess.Repositories
{
    public class UserRepository : BaseRepository<User, YYSDataContext>, IUserRepository
    {
        public async Task<User> LoginUser(string identityNo, string password)
        {
            return await GetAsync(prd => prd.IdentityNo == identityNo && prd.UserPassword == password);
        }
    }
}
