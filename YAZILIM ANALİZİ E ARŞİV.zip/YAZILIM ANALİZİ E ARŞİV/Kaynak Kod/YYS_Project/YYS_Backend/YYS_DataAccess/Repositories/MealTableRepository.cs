using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_DataAccess.Repositories
{
    public class MealTableRepository : BaseRepository<MealTable, YYSDataContext>, IMealTableRepository
    {
        public async Task<List<MealTable>> GetAllMeals() {
            return await GetAllAsync();
        }
    }
}
