using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;

namespace YYS_DataAccess.Repositories
{
    public class StudentDetailRepository : BaseRepository<StudentDetail, YYSDataContext>, IStudentDetailRepository
    {
        public async Task<StudentDetail> GetByStudentIdAsync(int studentId)
        {
            return await GetAsync(sd => sd.StudentId == studentId);
        }
    }
}
