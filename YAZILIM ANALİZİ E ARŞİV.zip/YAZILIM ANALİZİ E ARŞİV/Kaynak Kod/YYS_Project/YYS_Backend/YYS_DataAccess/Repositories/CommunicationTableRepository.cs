using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace YYS_DataAccess.Repositories
{
    public class CommunicationTableRepository : BaseRepository<CommunicationTable, YYSDataContext>, ICommunicationTableRepository
    {
        public async Task<List<CommunicationTable>> GetAllCommunicationTablesAsync()
        {
            return await GetAllAsync();
        }

        public async Task<List<CommunicationTable>> GetAllByUserIdAsync(int userId)
        {
            return await GetAllAsync(ct => ct.UserId == userId);
        }
    }
}
