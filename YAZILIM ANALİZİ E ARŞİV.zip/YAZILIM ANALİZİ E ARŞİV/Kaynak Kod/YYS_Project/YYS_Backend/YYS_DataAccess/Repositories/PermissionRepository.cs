using Utils;
using YYS_DataAccess.Context;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_DataAccess.Repositories
{
    public class PermissionRepository : BaseRepository<Permission, YYSDataContext>, IPermissionRepository
    {
        public async Task<List<Permission>> GetAllByStudentIdAsync(int studentId)
        {
            return await GetAllAsync(p => p.StudentId == studentId);
        }
    }
}
