using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommunicationTableController : BaseController
    {
        private readonly ICommunicationTableRepository _repository;

        public CommunicationTableController(ICommunicationTableRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAll")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _repository.GetAllCommunicationTablesAsync();
            var response = ApiResponse<List<CommunicationTable>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpGet("getAllByUserId/{userId}")]
        public async Task<IActionResult> GetAllByUserId(int userId)
        {
            var data = await _repository.GetAllByUserIdAsync(userId);
            var response = ApiResponse<List<CommunicationTable>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(CommunicationTable entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<CommunicationTable>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
