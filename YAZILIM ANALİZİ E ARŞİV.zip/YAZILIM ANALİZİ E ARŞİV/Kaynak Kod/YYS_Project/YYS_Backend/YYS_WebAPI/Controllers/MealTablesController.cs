using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MealTablesController : BaseController
    {
        private readonly IMealTableRepository _advisorCalendarRepository;
        public MealTablesController(IMealTableRepository advisorCalendarRepository)
        {
            _advisorCalendarRepository = advisorCalendarRepository;
        }

        [HttpGet("getAllMeals")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _advisorCalendarRepository.GetAllMeals();
            var response = ApiResponse<List<MealTable>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

    }
}
