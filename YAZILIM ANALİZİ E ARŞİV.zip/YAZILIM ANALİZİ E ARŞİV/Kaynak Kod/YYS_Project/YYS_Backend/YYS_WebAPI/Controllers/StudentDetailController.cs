using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentDetailController : BaseController
    {
        private readonly IStudentDetailRepository _repository;

        public StudentDetailController(IStudentDetailRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getByStudentId/{studentId}")]
        public async Task<IActionResult> GetByStudentId(int studentId)
        {
            var data = await _repository.GetByStudentIdAsync(studentId);
            if (data == null)
            {
                return NotFound();
            }

            var response = ApiResponse<StudentDetail>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(StudentDetail entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<StudentDetail>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
