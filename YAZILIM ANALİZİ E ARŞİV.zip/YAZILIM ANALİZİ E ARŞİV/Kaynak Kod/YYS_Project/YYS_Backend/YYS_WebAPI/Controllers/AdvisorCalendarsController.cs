﻿using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdvisorCalendarsController : BaseController
    {
        private readonly IAdvisorCalendarRepository _advisorCalendarRepository;
        public AdvisorCalendarsController(IAdvisorCalendarRepository advisorCalendarRepository)
        {
            _advisorCalendarRepository = advisorCalendarRepository;
        }

        [HttpGet("getAllIAdvisorCalendar")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _advisorCalendarRepository.GetAllAdvisorCalendar();
            var response = ApiResponse<List<AdvisorCalendar>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(AdvisorCalendar entity)
        {
            var data = await _advisorCalendarRepository.InsertAsync(entity);
            var response = ApiResponse<AdvisorCalendar>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }

    }
}
