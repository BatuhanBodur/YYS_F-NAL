using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentCourseRecordController : BaseController
    {
        private readonly IStudentCourseRecordRepository _repository;

        public StudentCourseRecordController(IStudentCourseRecordRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAllByUserId/{userId}")]
        public async Task<IActionResult> GetAllByUserId(int userId)
        {
            var data = await _repository.GetAllByUserIdAsync(userId);
            var response = ApiResponse<List<StudentCourseRecord>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpGet("getAllByCourseId/{courseId}")]
        public async Task<IActionResult> GetAllByCourseId(int courseId)
        {
            var data = await _repository.GetAllByCourseIdAsync(courseId);
            var response = ApiResponse<List<StudentCourseRecord>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(StudentCourseRecord entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<StudentCourseRecord>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
