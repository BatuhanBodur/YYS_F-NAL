using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SportReservationController : BaseController
    {
        private readonly ISportReservationRepository _repository;

        public SportReservationController(ISportReservationRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAll")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _repository.GetAllSportReservationsAsync();
            var response = ApiResponse<List<SportReservation>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(SportReservation entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<SportReservation>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
