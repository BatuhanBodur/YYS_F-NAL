using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GuestStudentController : BaseController
    {
        private readonly IGuestStudentRepository _repository;

        public GuestStudentController(IGuestStudentRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAll")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _repository.GetAllGuestStudentsAsync();
            var response = ApiResponse<List<GuestStudent>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(GuestStudent entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<GuestStudent>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
