using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomInformationController : BaseController
    {
        private readonly IRoomInformationRepository _repository;

        public RoomInformationController(IRoomInformationRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAll")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _repository.GetAllRoomInformationAsync();
            var response = ApiResponse<List<RoomInformation>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }
    }
}
