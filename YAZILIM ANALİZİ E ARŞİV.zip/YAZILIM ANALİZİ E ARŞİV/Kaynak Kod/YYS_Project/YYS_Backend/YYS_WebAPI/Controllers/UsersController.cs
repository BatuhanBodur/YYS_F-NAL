﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Core;
using YYS_Model.Dtos.User;
using YYS_Model.Entities;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : BaseController
    {

        private readonly IUserRepository userRepository;

        public UsersController(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        [HttpPost("Authentication")]
        public async Task<IActionResult> Login([FromBody] UserPostDto userPostDto)
        {
            var user = await userRepository.LoginUser(userPostDto.IdentityNo, userPostDto.UserPassword);
            if (user == null)
            {
                var response = new ApiResponse<NoData>() { ErrorMessages = new List<String> { "Kullanıcı kimlik numarası veya şifre hatalıdır."}, StatusCode = 200 };
                return SendResponse(response);
            }
            var res = new ApiResponse<User>() { Data = user, StatusCode = 200 };  
            return SendResponse(res);
        }

    }
}
