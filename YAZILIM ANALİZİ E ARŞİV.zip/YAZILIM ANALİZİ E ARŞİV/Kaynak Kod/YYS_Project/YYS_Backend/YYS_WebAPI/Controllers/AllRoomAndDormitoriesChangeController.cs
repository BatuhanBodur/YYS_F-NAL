using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AllRoomAndDormitoriesChangeController : BaseController
    {
        private readonly IAllRoomAndDormitoryChangeRepository _repository;

        public AllRoomAndDormitoriesChangeController(IAllRoomAndDormitoryChangeRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAll")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _repository.GetAllRoomAndDormitoryChangesAsync();
            var response = ApiResponse<List<AllRoomAndDormitoryChange>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpGet("getById/{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var data = await _repository.GetByIdAsync(id);
            if (data == null)
            {
                var errorResponse = ApiResponse<AllRoomAndDormitoryChange>.Fail(404, "Record not found");
                return SendResponse(errorResponse);
            }
            var response = ApiResponse<AllRoomAndDormitoryChange>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(AllRoomAndDormitoryChange entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<AllRoomAndDormitoryChange>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
