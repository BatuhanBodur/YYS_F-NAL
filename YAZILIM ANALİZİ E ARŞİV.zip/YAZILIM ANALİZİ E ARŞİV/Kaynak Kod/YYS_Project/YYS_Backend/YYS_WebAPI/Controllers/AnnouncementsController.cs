using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnnouncementsController : BaseController
    {
        private readonly IAnnouncementRepository _advisorCalendarRepository;
        public AnnouncementsController(IAnnouncementRepository advisorCalendarRepository)
        {
            _advisorCalendarRepository = advisorCalendarRepository;
        }

        [HttpGet("getAllAnnouncements")]
        public async Task<IActionResult> GetAll()
        {
            var data = await _advisorCalendarRepository.GetAllAsync();
            var response = ApiResponse<List<Announcement>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

    }
}
