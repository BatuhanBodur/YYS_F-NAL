using Microsoft.AspNetCore.Mvc;
using YYS_DataAccess.Interfaces;
using YYS_Model.Entities;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YYS_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PermissionController : BaseController
    {
        private readonly IPermissionRepository _repository;

        public PermissionController(IPermissionRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("getAllByStudentId/{studentId}")]
        public async Task<IActionResult> GetAllByStudentId(int studentId)
        {
            var data = await _repository.GetAllByStudentIdAsync(studentId);
            var response = ApiResponse<List<Permission>>.Success(data: data, statusCode: 200);
            return SendResponse(response);
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(Permission entity)
        {
            var data = await _repository.InsertAsync(entity);
            var response = ApiResponse<Permission>.Success(data: data, statusCode: 201);
            return SendResponse(response);
        }
    }
}
