﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YYS_Model.Dtos.User
{
    public class UserPostDto
    {
        public string IdentityNo { get; set; }
        public string UserPassword { get; set; }
    }
}
