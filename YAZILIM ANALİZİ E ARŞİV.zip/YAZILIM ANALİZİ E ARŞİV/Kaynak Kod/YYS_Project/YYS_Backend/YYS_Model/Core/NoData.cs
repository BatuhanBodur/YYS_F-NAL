﻿namespace YYS_Model.Core
{
    public class NoData
    {
        // Data olmadığında durum kodu dönmek istediğim zaman boş bir tip.
    }
}
