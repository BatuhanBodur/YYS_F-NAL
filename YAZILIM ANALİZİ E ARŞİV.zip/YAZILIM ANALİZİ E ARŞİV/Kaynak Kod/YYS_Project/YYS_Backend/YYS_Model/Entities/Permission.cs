﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Permission
    {
        [Key] public int PermissionId { get; set; }
        public int StudentId { get; set; }
        public string? PermissionUsedAddress { get; set; }
        public DateTime PermitExpirationDate { get; set; }
        public string? PermissionStatement { get; set; }
        public int ApprovedId { get; set; }
        public bool IsActive { get; set; }
    }
}
