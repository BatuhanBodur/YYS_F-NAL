﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class StudentPermission
    {
        [Key] public int Id { get; set; }
        public int StudentId { get; set; }
        public string? Address { get; set; }
        public DateTime ExitDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }
}
