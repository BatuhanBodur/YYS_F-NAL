﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class RoomInformation
    {
        [Key]public int Id { get; set; }
        public int RoomNo { get; set; }
        public int FloorNo { get; set; }
        public int BedNumber { get; set; }
        public int TotalPerson { get; set; }
        public int DormitoriesId { get; set; }
    }
}
