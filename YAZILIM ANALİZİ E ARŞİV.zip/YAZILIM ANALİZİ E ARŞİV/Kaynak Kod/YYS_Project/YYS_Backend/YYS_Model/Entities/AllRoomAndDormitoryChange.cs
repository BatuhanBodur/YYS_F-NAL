﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class AllRoomAndDormitoryChange
    {
        [Key]public int Id { get; set; }
        public int RequestingStudentId { get; set; }
        public int RequestedStudentId { get; set; }
        public int Status { get; set; }
    }
}
