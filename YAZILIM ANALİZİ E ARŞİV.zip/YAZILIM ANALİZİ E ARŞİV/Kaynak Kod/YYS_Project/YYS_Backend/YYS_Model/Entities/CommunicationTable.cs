﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class CommunicationTable
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? Description { get; set; }
    }
}
