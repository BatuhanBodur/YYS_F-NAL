﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class MealTable
    {
        [Key] public int Id { get; set; }
        public string? StarterMeal { get; set; }
        public string? MainMeal { get; set; }
        public string? Dessert { get; set; }
        public string? Drink { get; set; }
        public DateTime MealDate { get; set; }
    }
}
