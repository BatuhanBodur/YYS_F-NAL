﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class StudentDetail
    {
        [Key] public int DetailId { get; set; }
        public int StudentId { get; set; }
        public string? DormitoryBlock { get; set; }
        public string? DormitoryFloor { get; set; }
        public string? DormitoryRoomNumber { get; set; }
        public string? DormitoryBedNumber { get; set; }
    }
}
