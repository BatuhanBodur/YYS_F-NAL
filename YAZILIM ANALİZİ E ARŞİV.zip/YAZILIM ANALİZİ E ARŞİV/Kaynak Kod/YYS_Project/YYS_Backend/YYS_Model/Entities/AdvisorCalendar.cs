﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class AdvisorCalendar
    {
        [Key] public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime AdvisortDate { get; set; }
        public int Period { get; set; }
        public bool IsActive { get; set; }
    }
}
