﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Dormitorie
    {
        [Key]public int Id { get; set; }
        public int DormitoryQuota { get; set; }
        public int RoomNumber { get; set; }
        public string? DormitoryName { get; set; }
        public string? DormitoryAddress { get; set; }
    }
}
