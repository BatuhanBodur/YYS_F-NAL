﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Role
    {
        [Key] public int RoleId { get; set; }
        public string? RoleName { get; set; }
        public bool IsActive { get; set; }
    }
}
