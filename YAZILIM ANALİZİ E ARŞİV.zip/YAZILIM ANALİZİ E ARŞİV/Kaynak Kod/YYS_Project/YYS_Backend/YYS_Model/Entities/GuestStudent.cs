﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class GuestStudent
    {
        [Key] public int Id { get; set; }
        public string? Name { get; set; }
        public string? Surname { get; set; }
        public string? IdentityNo { get; set; }
        public string? PhoneNumber { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
