﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Course
    {
        [Key]public int Id { get; set; }
        public string? CourseName { get; set; }
        public DateTime CourseDate { get; set; }
        public int CourseQuota { get; set; }
        public string? CourseDays { get; set; }
        public int MentorUserId { get; set; }
        public bool IsActive { get; set; }
    }
}
