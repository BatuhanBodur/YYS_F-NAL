﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YYS_Model.Entities
{
    public class User
    {
        [Key] public int UserId { get; set; }
        public string? IdentityNo { get; set; }
        public string? UserFullName { get; set; }
        public string? UserPassword { get; set; }
        public string? UserAddress { get; set; }
        public string? UserPhone { get; set; }
        public string? UserEmail { get; set; }
        public int USerRole { get; set; }
        public bool IsActive { get; set; }
    }
}
