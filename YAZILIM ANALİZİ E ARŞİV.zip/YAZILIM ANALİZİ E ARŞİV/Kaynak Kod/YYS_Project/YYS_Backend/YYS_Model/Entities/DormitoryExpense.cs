﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class DormitoryExpense
    {
        [Key]
        public int Id { get; set; }
        public int ExpenseType { get; set; }
        public decimal SpendingAmount { get; set; }
        public DateTime SpendingTime { get; set; }
    }
}
