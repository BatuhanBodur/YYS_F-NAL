﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Payment
    {
        [Key]public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime Period { get; set; }
        public bool IsPayment { get; set; }
        public int Price { get; set; }
    }
}
