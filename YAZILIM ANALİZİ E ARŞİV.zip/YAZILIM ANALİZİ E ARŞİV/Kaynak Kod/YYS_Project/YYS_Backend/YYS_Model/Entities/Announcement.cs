﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class Announcement
    {
        [Key]public int Id { get; set; }
        public string? AnnouncementsTitle { get; set; }
        public string? AnnouncementsDescription { get; set; }
        public string? AnnouncementsImage { get; set; }
        public DateTime AnnouncementsDate { get; set; }
        public bool IsActive { get; set; }
    }
}
