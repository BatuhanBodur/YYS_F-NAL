﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class StudentCourseRecord
    {
        [Key]public int Id { get; set; }
        public int UserId { get; set; }
        public int CourseId { get; set; }
    }
}
