﻿using System.ComponentModel.DataAnnotations;

namespace YYS_Model.Entities
{
    public class SportReservation
    {
        [Key] public int Id { get; set; }
        public int SportType { get; set; }
        public DateTime SportDate { get; set; }
        public int Period { get; set; }
        public bool IsActive { get; set; }
    }
}
