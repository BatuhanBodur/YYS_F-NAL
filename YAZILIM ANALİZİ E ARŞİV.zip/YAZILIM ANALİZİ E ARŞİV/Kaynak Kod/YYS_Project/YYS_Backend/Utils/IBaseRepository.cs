﻿using System.Linq.Expressions;

namespace Utils
{
    public interface IBaseRepository<TEntity> // Model/Entities -> SQL de tablolarak denk gelecek modeller tablolar.
    {
        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate = null);
        Task<TEntity> GetAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> InsertAsync(TEntity entity);
        Task UpdateAsync(TEntity entity);
        Task DeleteAsync(TEntity entity);
    }
}
