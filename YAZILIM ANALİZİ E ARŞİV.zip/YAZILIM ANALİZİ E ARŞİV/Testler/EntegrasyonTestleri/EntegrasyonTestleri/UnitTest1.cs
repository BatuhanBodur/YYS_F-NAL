using Xunit;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using YYS_Model.Entities;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Headers;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace YYS_WebAPI.IntegrationTests
{
    // Previous test classes remain the same...

    public class PaymentTests : TestBase
    {
        [Fact]
        public async Task Create_ValidPayment_ShouldReturnCreatedPayment()
        {
            var payment = new Payment
            {
                UserId = 1,
                Period = DateTime.Now,
                IsPayment = true,
                Price = 1000
            };

            var response = await _client.PostAsync("/api/Payment/create", CreateJsonContent(payment));
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ApiResponse<Payment>>(content);

            Assert.Equal(201, (int)response.StatusCode);
            Assert.NotNull(result.Data);
            Assert.Equal(payment.Price, result.Data.Price);
        }

        [Fact]
        public async Task GetPaymentsByUserId_ShouldReturnUserPayments()
        {
            int userId = 1;
            var response = await _client.GetAsync($"/api/Payment/getByUserId/{userId}");
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ApiResponse<List<Payment>>>(content);

            Assert.Equal(200, (int)response.StatusCode);
            Assert.NotNull(result.Data);
        }

        [Fact]
        public async Task GetUnpaidPayments_ShouldReturnUnpaidPayments()
        {
            var response = await _client.GetAsync("/api/Payment/getUnpaidPayments");
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ApiResponse<List<Payment>>>(content);

            Assert.Equal(200, (int)response.StatusCode);
            Assert.NotNull(result.Data);
            Assert.All(result.Data, payment => Assert.False(payment.IsPayment));
        }
    }

    public class AuthorizationTests : TestBase
    {
        private string GenerateTestToken(string role)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Role, role),
                new Claim(ClaimTypes.NameIdentifier, "1")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("your-secret-key"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "test-issuer",
                audience: "test-audience",
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [Theory]
        [InlineData("Admin")]
        [InlineData("Student")]
        [InlineData("Mentor")]
        public async Task Endpoint_WithValidRole_ShouldAllowAccess(string role)
        {
            // Arrange
            var token = GenerateTestToken(role);
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            // Act
            var response = await _client.GetAsync("/api/StudentDetail/getByStudentId/1");

            // Assert
            Assert.NotEqual(403, (int)response.StatusCode);
        }

        [Fact]
        public async Task AdminEndpoint_WithNonAdminRole_ShouldDenyAccess()
        {
            // Arrange
            var token = GenerateTestToken("Student");
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            // Act
            var response = await _client.GetAsync("/api/Admin/someAdminEndpoint");

            // Assert
            Assert.Equal(403, (int)response.StatusCode);
        }
    }

    public class FileUploadTests : TestBase
    {
        [Fact]
        public async Task UploadAnnouncementImage_ValidImage_ShouldSucceed()
        {
            // Arrange
            var imageContent = new ByteArrayContent(new byte[100]); // Dummy image data
            imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");

            var formData = new MultipartFormDataContent();
            formData.Add(imageContent, "image", "test.jpg");

            // Act
            var response = await _client.PostAsync("/api/Announcements/uploadImage", formData);
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ApiResponse<string>>(content);

            // Assert
            Assert.Equal(200, (int)response.StatusCode);
            Assert.NotNull(result.Data); // Image URL
        }

        [Fact]
        public async Task UploadAnnouncementImage_InvalidFormat_ShouldFail()
        {
            // Arrange
            var textContent = new ByteArrayContent(Encoding.UTF8.GetBytes("Not an image"));
            textContent.Headers.ContentType = MediaTypeHeaderValue.Parse("text/plain");

            var formData = new MultipartFormDataContent();
            formData.Add(textContent, "image", "test.txt");

            // Act
            var response = await _client.PostAsync("/api/Announcements/uploadImage", formData);

            // Assert
            Assert.Equal(400, (int)response.StatusCode);
        }
    }

    public class ConcurrencyTests : TestBase
    {
        [Fact]
        public async Task MultipleCourseRegistrations_ShouldRespectQuota()
        {
            // Arrange
            var courseId = 1;
            var record = new StudentCourseRecord { CourseId = courseId };
            var tasks = new List<Task<HttpResponseMessage>>();

            // Act - Simulate multiple concurrent registrations
            for (int i = 0; i < 10; i++)
            {
                tasks.Add(_client.PostAsync("/api/StudentCourseRecord/create", CreateJsonContent(record)));
            }

            await Task.WhenAll(tasks);

            // Assert - Check course quota wasn't exceeded
            var response = await _client.GetAsync($"/api/Course/getById/{courseId}");
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<ApiResponse<Course>>(content);

            Assert.NotNull(result.Data);
            Assert.True(result.Data.CourseQuota >= 0);
        }

        [Fact]
        public async Task MultipleSportReservations_ShouldPreventDoubleBooking()
        {
            // Arrange
            var reservation = new SportReservation
            {
                SportType = 1,
                SportDate = DateTime.Now,
                Period = 1
            };

            var tasks = new List<Task<HttpResponseMessage>>();

            // Act - Simulate multiple concurrent reservations
            for (int i = 0; i < 5; i++)
            {
                tasks.Add(_client.PostAsync("/api/SportReservation/create", CreateJsonContent(reservation)));
            }

            var responses = await Task.WhenAll(tasks);

            // Assert - Only one reservation should succeed
            var successCount = responses.Count(r => r.StatusCode == System.Net.HttpStatusCode.Created);
            Assert.Equal(1, successCount);
        }
    }

    public class PerformanceTests : TestBase
    {
        [Fact]
        public async Task GetAllCourses_ShouldRespondQuickly()
        {
            // Arrange
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Act
            var response = await _client.GetAsync("/api/Course/getAll");

            // Assert
            stopwatch.Stop();
            Assert.True(stopwatch.ElapsedMilliseconds < 1000); // Response under 1 second
        }

        [Fact]
        public async Task BulkOperations_ShouldHandleLargeData()
        {
            // Arrange
            var announcements = Enumerable.Range(1, 100).Select(i => new Announcement
            {
                AnnouncementsTitle = $"Test {i}",
                AnnouncementsDescription = $"Description {i}",
                AnnouncementsDate = DateTime.Now,
                IsActive = true
            }).ToList();

            // Act
            var tasks = announcements.Select(a =>
                _client.PostAsync("/api/Announcements/create", CreateJsonContent(a)));
            var responses = await Task.WhenAll(tasks);

            // Assert
            Assert.All(responses, r => Assert.Equal(201, (int)r.StatusCode));
        }

        [Fact]
        public async Task ConcurrentRequests_ShouldMaintainPerformance()
        {
            // Arrange
            var endpoints = new[]
            {
                "/api/Course/getAll",
                "/api/Dormitorie/getAll",
                "/api/MealTables/getAllMeals",
                "/api/Announcements/getAllAnnouncements"
            };

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Act - Simulate multiple users accessing different endpoints
            var tasks = endpoints.Select(e => _client.GetAsync(e));
            var responses = await Task.WhenAll(tasks);

            // Assert
            stopwatch.Stop();
            Assert.True(stopwatch.ElapsedMilliseconds < 2000); // All responses under 2 seconds
            Assert.All(responses, r => Assert.Equal(200, (int)r.StatusCode));
        }
    }
}