using Xunit;
using YYS_Model.Entities;
using System;
using System.Data;
using System.Security;

namespace YYS_Model.Tests
{
    public class EntityModelTests
    {
        [Fact]
        public void User_Properties_Work_As_Expected()
        {
            // Arrange
            var user = new User
            {
                UserId = 1,
                IdentityNo = "12345678901",
                UserFullName = "John Doe",
                UserPassword = "hashedPassword123",
                UserAddress = "123 Main St",
                UserPhone = "555-0123",
                UserEmail = "john@example.com",
                USerRole = 1,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, user.UserId);
            Assert.Equal("12345678901", user.IdentityNo);
            Assert.Equal("John Doe", user.UserFullName);
            Assert.Equal("hashedPassword123", user.UserPassword);
            Assert.Equal("123 Main St", user.UserAddress);
            Assert.Equal("555-0123", user.UserPhone);
            Assert.Equal("john@example.com", user.UserEmail);
            Assert.Equal(1, user.USerRole);
            Assert.True(user.IsActive);
        }

        [Fact]
        public void AdvisorCalendar_Properties_Work_As_Expected()
        {
            // Arrange
            var calendar = new AdvisorCalendar
            {
                Id = 1,
                UserId = 1,
                AdvisortDate = new DateTime(2025, 1, 1),
                Period = 1,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, calendar.Id);
            Assert.Equal(1, calendar.UserId);
            Assert.Equal(new DateTime(2025, 1, 1), calendar.AdvisortDate);
            Assert.Equal(1, calendar.Period);
            Assert.True(calendar.IsActive);
        }

        [Fact]
        public void AllRoomAndDormitoryChange_Properties_Work_As_Expected()
        {
            // Arrange
            var change = new AllRoomAndDormitoryChange
            {
                Id = 1,
                RequestingStudentId = 1,
                RequestedStudentId = 2,
                Status = 0
            };

            // Assert
            Assert.Equal(1, change.Id);
            Assert.Equal(1, change.RequestingStudentId);
            Assert.Equal(2, change.RequestedStudentId);
            Assert.Equal(0, change.Status);
        }

        [Fact]
        public void Announcement_Properties_Work_As_Expected()
        {
            // Arrange
            var announcement = new Announcement
            {
                Id = 1,
                AnnouncementsTitle = "Test Announcement",
                AnnouncementsDescription = "Test Description",
                AnnouncementsImage = "test.jpg",
                AnnouncementsDate = new DateTime(2025, 1, 1),
                IsActive = true
            };

            // Assert
            Assert.Equal(1, announcement.Id);
            Assert.Equal("Test Announcement", announcement.AnnouncementsTitle);
            Assert.Equal("Test Description", announcement.AnnouncementsDescription);
            Assert.Equal("test.jpg", announcement.AnnouncementsImage);
            Assert.Equal(new DateTime(2025, 1, 1), announcement.AnnouncementsDate);
            Assert.True(announcement.IsActive);
        }

        [Fact]
        public void CommunicationTable_Properties_Work_As_Expected()
        {
            // Arrange
            var communication = new CommunicationTable
            {
                Id = 1,
                UserId = 1,
                CreatedDate = new DateTime(2025, 1, 1),
                Description = "Test Communication"
            };

            // Assert
            Assert.Equal(1, communication.Id);
            Assert.Equal(1, communication.UserId);
            Assert.Equal(new DateTime(2025, 1, 1), communication.CreatedDate);
            Assert.Equal("Test Communication", communication.Description);
        }

        [Fact]
        public void Course_Properties_Work_As_Expected()
        {
            // Arrange
            var course = new Course
            {
                Id = 1,
                CourseName = "Mathematics",
                CourseDate = new DateTime(2025, 1, 1),
                CourseQuota = 30,
                CourseDays = "Monday,Wednesday",
                MentorUserId = 1,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, course.Id);
            Assert.Equal("Mathematics", course.CourseName);
            Assert.Equal(new DateTime(2025, 1, 1), course.CourseDate);
            Assert.Equal(30, course.CourseQuota);
            Assert.Equal("Monday,Wednesday", course.CourseDays);
            Assert.Equal(1, course.MentorUserId);
            Assert.True(course.IsActive);
        }

        [Fact]
        public void Dormitorie_Properties_Work_As_Expected()
        {
            // Arrange
            var dormitory = new Dormitorie
            {
                Id = 1,
                DormitoryQuota = 100,
                RoomNumber = 50,
                DormitoryName = "Block A",
                DormitoryAddress = "Campus Main Road"
            };

            // Assert
            Assert.Equal(1, dormitory.Id);
            Assert.Equal(100, dormitory.DormitoryQuota);
            Assert.Equal(50, dormitory.RoomNumber);
            Assert.Equal("Block A", dormitory.DormitoryName);
            Assert.Equal("Campus Main Road", dormitory.DormitoryAddress);
        }

        [Fact]
        public void DormitoryExpense_Properties_Work_As_Expected()
        {
            // Arrange
            var expense = new DormitoryExpense
            {
                Id = 1,
                ExpenseType = 1,
                SpendingAmount = 100.50M,
                SpendingTime = new DateTime(2025, 1, 1)
            };

            // Assert
            Assert.Equal(1, expense.Id);
            Assert.Equal(1, expense.ExpenseType);
            Assert.Equal(100.50M, expense.SpendingAmount);
            Assert.Equal(new DateTime(2025, 1, 1), expense.SpendingTime);
        }

        [Fact]
        public void GuestStudent_Properties_Work_As_Expected()
        {
            // Arrange
            var guest = new GuestStudent
            {
                Id = 1,
                Name = "John",
                Surname = "Doe",
                IdentityNo = "12345678901",
                PhoneNumber = "555-0123",
                StartDate = new DateTime(2025, 1, 1),
                EndDate = new DateTime(2025, 1, 7),
                TotalPrice = 350.00M
            };

            // Assert
            Assert.Equal(1, guest.Id);
            Assert.Equal("John", guest.Name);
            Assert.Equal("Doe", guest.Surname);
            Assert.Equal("12345678901", guest.IdentityNo);
            Assert.Equal("555-0123", guest.PhoneNumber);
            Assert.Equal(new DateTime(2025, 1, 1), guest.StartDate);
            Assert.Equal(new DateTime(2025, 1, 7), guest.EndDate);
            Assert.Equal(350.00M, guest.TotalPrice);
        }

        [Fact]
        public void MealTable_Properties_Work_As_Expected()
        {
            // Arrange
            var meal = new MealTable
            {
                Id = 1,
                StarterMeal = "Soup",
                MainMeal = "Chicken",
                Dessert = "Ice Cream",
                Drink = "Water",
                MealDate = new DateTime(2025, 1, 1)
            };

            // Assert
            Assert.Equal(1, meal.Id);
            Assert.Equal("Soup", meal.StarterMeal);
            Assert.Equal("Chicken", meal.MainMeal);
            Assert.Equal("Ice Cream", meal.Dessert);
            Assert.Equal("Water", meal.Drink);
            Assert.Equal(new DateTime(2025, 1, 1), meal.MealDate);
        }

        [Fact]
        public void Payment_Properties_Work_As_Expected()
        {
            // Arrange
            var payment = new Payment
            {
                Id = 1,
                UserId = 1,
                Period = new DateTime(2025, 1, 1),
                IsPayment = true,
                Price = 1000
            };

            // Assert
            Assert.Equal(1, payment.Id);
            Assert.Equal(1, payment.UserId);
            Assert.Equal(new DateTime(2025, 1, 1), payment.Period);
            Assert.True(payment.IsPayment);
            Assert.Equal(1000, payment.Price);
        }

        [Fact]
        public void Permission_Properties_Work_As_Expected()
        {
            // Arrange
            var permission = new Permission
            {
                PermissionId = 1,
                StudentId = 1,
                PermissionUsedAddress = "Home Address",
                PermitExpirationDate = new DateTime(2025, 1, 1),
                PermissionStatement = "Weekend Leave",
                ApprovedId = 1,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, permission.PermissionId);
            Assert.Equal(1, permission.StudentId);
            Assert.Equal("Home Address", permission.PermissionUsedAddress);
            Assert.Equal(new DateTime(2025, 1, 1), permission.PermitExpirationDate);
            Assert.Equal("Weekend Leave", permission.PermissionStatement);
            Assert.Equal(1, permission.ApprovedId);
            Assert.True(permission.IsActive);
        }

        [Fact]
        public void Role_Properties_Work_As_Expected()
        {
            // Arrange
            var role = new Role
            {
                RoleId = 1,
                RoleName = "Admin",
                IsActive = true
            };

            // Assert
            Assert.Equal(1, role.RoleId);
            Assert.Equal("Admin", role.RoleName);
            Assert.True(role.IsActive);
        }

        [Fact]
        public void RoomInformation_Properties_Work_As_Expected()
        {
            // Arrange
            var room = new RoomInformation
            {
                Id = 1,
                RoomNo = 101,
                FloorNo = 1,
                BedNumber = 2,
                TotalPerson = 2,
                DormitoriesId = 1
            };

            // Assert
            Assert.Equal(1, room.Id);
            Assert.Equal(101, room.RoomNo);
            Assert.Equal(1, room.FloorNo);
            Assert.Equal(2, room.BedNumber);
            Assert.Equal(2, room.TotalPerson);
            Assert.Equal(1, room.DormitoriesId);
        }

        [Fact]
        public void SportReservation_Properties_Work_As_Expected()
        {
            // Arrange
            var reservation = new SportReservation
            {
                Id = 1,
                SportType = 1,
                SportDate = new DateTime(2025, 1, 1),
                Period = 1,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, reservation.Id);
            Assert.Equal(1, reservation.SportType);
            Assert.Equal(new DateTime(2025, 1, 1), reservation.SportDate);
            Assert.Equal(1, reservation.Period);
            Assert.True(reservation.IsActive);
        }

        [Fact]
        public void StudentCourseRecord_Properties_Work_As_Expected()
        {
            // Arrange
            var record = new StudentCourseRecord
            {
                Id = 1,
                UserId = 1,
                CourseId = 1
            };

            // Assert
            Assert.Equal(1, record.Id);
            Assert.Equal(1, record.UserId);
            Assert.Equal(1, record.CourseId);
        }

        [Fact]
        public void StudentDetail_Properties_Work_As_Expected()
        {
            // Arrange
            var studentDetail = new StudentDetail
            {
                DetailId = 1,
                StudentId = 1,
                DormitoryBlock = "A",
                DormitoryFloor = "2",
                DormitoryRoomNumber = "201",
                DormitoryBedNumber = "1"
            };

            // Assert
            Assert.Equal(1, studentDetail.DetailId);
            Assert.Equal(1, studentDetail.StudentId);
            Assert.Equal("A", studentDetail.DormitoryBlock);
            Assert.Equal("2", studentDetail.DormitoryFloor);
            Assert.Equal("201", studentDetail.DormitoryRoomNumber);
            Assert.Equal("1", studentDetail.DormitoryBedNumber);
        }

        [Fact]
        public void StudentPermission_Properties_Work_As_Expected()
        {
            // Arrange
            var permission = new StudentPermission
            {
                Id = 1,
                StudentId = 1,
                Address = "Home Address",
                ExitDate = new DateTime(2025, 1, 1),
                ReturnDate = new DateTime(2025, 1, 7),
                Description = "Weekend Leave",
                IsActive = true
            };

            // Assert
            Assert.Equal(1, permission.Id);
            Assert.Equal(1, permission.StudentId);
            Assert.Equal("Home Address", permission.Address);
            Assert.Equal(new DateTime(2025, 1, 1), permission.ExitDate);
            Assert.Equal(new DateTime(2025, 1, 7), permission.ReturnDate);
            Assert.Equal("Weekend Leave", permission.Description);
            Assert.True(permission.IsActive);
        }
    }
}